
chrome.devtools.panels.create(
  "Bitwave CSV Export",
  "icon.png",
  "panel.html"
);
