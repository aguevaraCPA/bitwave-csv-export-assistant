
document.getElementById("download").addEventListener("click", () => {
  const selected = document.getElementById("operation").value;

  chrome.devtools.network.getHAR((harLog) => {
    const entries = harLog.entries.reverse();
    const match = entries.find(entry => {
      const postData = entry.request.postData?.text || "";
      return postData.includes(`"operationName":"${selected}"`);
    });

    if (!match) {
      document.getElementById("status").innerText = "❌ No matching request found.";
      return;
    }

    match.getContent((body, encoding) => {
      try {
        const json = JSON.parse(body);
        let rows, key;

        if (true) {
          const data = json.data;
          key = Object.keys(data).find(k => k.toLowerCase().includes(selected.toLowerCase().replace("get", "")));
          
        const rules = data[key];
        rows = [];

        for (const rule of rules) {
          const base = { ...rule };
          delete base.action;

          const action = rule.action || {};
          if (action.__typename === "DetailedCategorizationAction" && Array.isArray(action.lines)) {
            for (const line of action.lines) {
              rows.push({
                ...base,
                actionType: action.type,
                valueExtractor: line.valueExtractor,
                assetExtractor: line.assetExtractor,
                lineQualifierExtractor: JSON.stringify(line.lineQualifierExtractor),
                contactId: line.contactId,
                categoryId: line.categoryId,
                metadataIds: line.metadataIds ? line.metadataIds.join(", ") : "",
              });
            }
          } else {
            rows.push(rule);
          }
        }
    
          if (!Array.isArray(rows)) throw new Error(`Key '${key}' is not an array`);
        }

        const headers = Object.keys(rows[0]);
        const csv = [headers.join(",")].concat(
          rows.map(r => headers.map(h => '"' + String(r[h] ?? "").replace(/"/g, '""') + '"').join(","))
        ).join("\n");

        const blob = new Blob([csv], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `bitwave_${key}_${Date.now()}.csv`;
        a.click();

        document.getElementById("status").innerText = `✅ Exported ${rows.length} rows from '${key}'`;

      } catch (e) {
        console.error("Parse error:", e);
        document.getElementById("status").innerText = "❌ Failed to parse or export CSV.";
      }
    });
  });
});
